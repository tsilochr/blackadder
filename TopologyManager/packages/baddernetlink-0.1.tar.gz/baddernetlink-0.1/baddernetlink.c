/*
BlackAdder Netlink. BlackAdder Native support.
ITI CERTH for Pursuit FP7 Project, Dimitris Syrivelis
*/

#include <Python.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <linux/netlink.h>
#include <string.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <time.h>
#include <sys/time.h>

int counter = 0;
unsigned char pursuit_id_len;
static struct sockaddr_nl d_nladdr;

#define NETLINK_BADDER 20
#define PUBLISH_DATA  8
#define PUBLISHED_DATA 104
#define PURSUIT_ID_LEN 8

static PyObject *baddernetlink_baddersend(PyObject *, PyObject *, PyObject *);
static PyObject *baddernetlink_badderrecv(PyObject *, PyObject *, PyObject *);
static PyObject *baddernetlink_badderconnectioninit(PyObject *, PyObject *, PyObject *);
static PyObject *baddernetlink_badderdisconnect(PyObject *, PyObject *, PyObject *);

static PyMethodDef baddernetlink_methods[] = {
    {"baddersend", (PyCFunction)baddernetlink_baddersend, METH_VARARGS|METH_KEYWORDS, NULL},
    {"badderrecv", (PyCFunction)baddernetlink_badderrecv, METH_VARARGS|METH_KEYWORDS, NULL},
    {"badderconnectioninit", (PyCFunction)baddernetlink_badderconnectioninit, METH_VARARGS|METH_KEYWORDS, NULL},
    {"badderdisconnect", (PyCFunction)baddernetlink_badderdisconnect, METH_VARARGS|METH_KEYWORDS, NULL},
    {NULL, NULL, 0, NULL}
};

static PyObject *baddernetlink_badderconnectioninit(PyObject *self, PyObject *args, 
				 PyObject *keywds) {

    char * type; 
    unsigned int ret;
    int sock_fd;  
    static struct sockaddr_nl s_nladdr;

    static char *kwlist[] = {"type","PursuitIDlen",NULL};

    if (!PyArg_ParseTupleAndKeywords(args, keywds, "s|B", kwlist,
				     &type,&pursuit_id_len)) { return NULL; }

    if (strcmp(type,"kernel") == 0) {

	sock_fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_BADDER);
    	if (sock_fd < 0) {
        	perror("socket");
    	}
    	/* source address */
    	memset(&s_nladdr, 0, sizeof (s_nladdr));
    	s_nladdr.nl_family = AF_NETLINK;
    	s_nladdr.nl_pad = 0;
    	s_nladdr.nl_pid = getpid();
    	ret = bind(sock_fd, (struct sockaddr*) &s_nladdr, sizeof (s_nladdr));
    	if (ret < 0) {
       	 perror("bind");
    	}
    	/* destination address */
    	memset(&d_nladdr, 0, sizeof (d_nladdr));
    	d_nladdr.nl_family = AF_NETLINK;
    	d_nladdr.nl_pad = 0;
    	d_nladdr.nl_pid = 0; /* destined to kernel */
	ret = 40;
	return Py_BuildValue("i", sock_fd);

    } else {

	sock_fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_GENERIC);
    	if (sock_fd < 0) {
        	perror("socket");
    	}
    	/* source address */
    	memset(&s_nladdr, 0, sizeof (s_nladdr));
    	s_nladdr.nl_family = AF_NETLINK;
    	s_nladdr.nl_pad = 0;
    	s_nladdr.nl_pid = getpid();
    	ret = bind(sock_fd, (struct sockaddr*) &s_nladdr, sizeof (s_nladdr));
    	if (ret < 0) {
       	 	perror("bind");
    	}
    	/* destination address */
    	memset(&d_nladdr, 0, sizeof (d_nladdr));
    	d_nladdr.nl_family = AF_NETLINK;
    	d_nladdr.nl_pad = 0;
    	d_nladdr.nl_pid = 9999; /* destined to user */
	return Py_BuildValue("i", sock_fd);

    }
   
    
}


static PyObject *baddernetlink_baddersend(PyObject *self, PyObject *args, 
				 PyObject *keywds) {
    struct msghdr msg;
    int sock_fd;
    struct iovec iov[8];
    struct nlmsghdr nlh;
    int ret = 0;
    static char *kwlist[] = {"sockfd","type", "idlen","id", "pidlen", "prefixid","strategy","LID","data", NULL};

    unsigned char type;
    unsigned char idlen;
    unsigned int idlen2;
    unsigned char pidlen;
    unsigned int pidlen2;
    unsigned char strategy;
    unsigned int lidlen;
    unsigned char * id;
    unsigned char * pid;
    unsigned char * lid; 
    unsigned char * data;
    unsigned int datalen;
    int k;
    iov[0].iov_base = &nlh;
    iov[0].iov_len = sizeof(struct nlmsghdr); 

    if (!PyArg_ParseTupleAndKeywords(args, keywds, "iBBz#Bz#Bz#z#", kwlist,
					&sock_fd,
				     	&type,
					&idlen,
				     	&id,
				     	&idlen2,
					&pidlen,
				     	&pid,
				     	&pidlen2,
				     	&strategy,
				     	&lid,	
				     	&lidlen,
				     	&data,
					&datalen))
        return NULL;

   if (type != PUBLISH_DATA) {

    	iov[1].iov_base = &type;
    	iov[2].iov_base = &idlen;
    	iov[4].iov_base = &pidlen;
    	iov[6].iov_base = &strategy;
    	iov[3].iov_base = id;
    	iov[5].iov_base = pid;
    	iov[7].iov_base = lid;
   
    	nlh.nlmsg_len = sizeof (struct nlmsghdr) + 1 /*type*/ + 1 /*for id length*/ + (idlen*pursuit_id_len) \
				+ 1 /*for prefix_id length*/ +  (pidlen*pursuit_id_len) + 1 /*strategy*/ + lidlen /*optional LID*/;
    	nlh.nlmsg_pid = getpid();
    	nlh.nlmsg_flags = 1;
    	nlh.nlmsg_type = 0;

 	iov[1].iov_len = sizeof (unsigned char);
    	iov[2].iov_len = sizeof (unsigned char);
    	iov[3].iov_len = idlen2;
    	iov[4].iov_len = sizeof (unsigned char);
    	iov[5].iov_len = pidlen2;
    	iov[6].iov_len = sizeof (unsigned char);
    	iov[7].iov_len = lidlen;

    	memset(&msg, 0, sizeof (msg));
    	msg.msg_name = (void *) &d_nladdr;
    	msg.msg_namelen = sizeof (d_nladdr);
    	msg.msg_iov = iov;

    	/*if there is no lid*/
    	if( lidlen == 0) {
        	msg.msg_iovlen = 7;
    	} else {   
        	msg.msg_iovlen = 8;
    	}
    	sendmsg(sock_fd, &msg, 0);
    	return Py_BuildValue("i", ret);
 } else {
    	/*PUBLISH DATA Handling*/
    	nlh.nlmsg_len = sizeof (struct nlmsghdr) + 1 /*type*/ + 1 /*for id length*/ + (idlen*pursuit_id_len) + datalen;
    	nlh.nlmsg_pid = getpid();
    	nlh.nlmsg_flags = 1;
    	nlh.nlmsg_type = 0;

    	iov[1].iov_base = &type;
    	iov[2].iov_base = &idlen;
    	iov[3].iov_base = id;
	iov[4].iov_base = &strategy;
        if(lidlen!=0){ 
           iov[5].iov_base = lid;
	   iov[5].iov_len = lidlen;
	   iov[6].iov_base = data;
           iov[6].iov_len = datalen;
        } else {
    	   iov[5].iov_base = (void *) data;
	   iov[5].iov_len = datalen;
        }
    	iov[1].iov_len = sizeof (unsigned char);
    	iov[2].iov_len = sizeof (unsigned char);
    	iov[3].iov_len = idlen*pursuit_id_len;
        iov[4].iov_len = sizeof(unsigned char);
   
    	memset(&msg, 0, sizeof (msg));
    	msg.msg_name = (void *) &d_nladdr;
    	msg.msg_namelen = sizeof (d_nladdr);
    	msg.msg_iov = iov;
	if(lidlen!=0){ 
    	   msg.msg_iovlen = 7;
        } else {
	   msg.msg_iovlen = 6;
	}
    	sendmsg(sock_fd, &msg, 0);
    	return Py_BuildValue("i", ret);
 }

}


static PyObject *baddernetlink_badderrecv(PyObject *self, PyObject *args, PyObject *keywds) {

    int total_buf_size;
    int bytes_read;
    int sock_fd;
    unsigned char type;
    unsigned char id_len;
    char *data;
    unsigned int datalen;
    unsigned char *str_id; 

    char buf[100000];
    char fake_buf[1];
  
    static char *kwlist[] = {"sockfd",NULL};

    if (!PyArg_ParseTupleAndKeywords(args, keywds, "I", kwlist,
				     &sock_fd)) { return NULL; }

    /*Blocking I/O Operation starts Here, Use the macros to release GIL*/
    Py_BEGIN_ALLOW_THREADS
    total_buf_size = recv(sock_fd, fake_buf, 1, MSG_PEEK | MSG_TRUNC | MSG_WAITALL);
    bytes_read = recv(sock_fd, buf, total_buf_size, MSG_WAITALL);
    Py_END_ALLOW_THREADS

    type = *(buf + sizeof (struct nlmsghdr));
    id_len = *(buf + sizeof (struct nlmsghdr) + sizeof (unsigned char));
    str_id = (unsigned char *)(buf + sizeof (struct nlmsghdr) + sizeof (unsigned char) + sizeof (unsigned char));
	
    if (type == PUBLISHED_DATA) {
       	 	data = buf + sizeof(struct nlmsghdr) + sizeof(unsigned char) + sizeof(unsigned char) + ((int) id_len) * PURSUIT_ID_LEN;
        	datalen = bytes_read - (sizeof(struct nlmsghdr) + sizeof(unsigned char) + sizeof(unsigned char) + (((int) id_len) * PURSUIT_ID_LEN));
        	return Py_BuildValue("(B,B,z#,z#)", type, id_len, str_id, (id_len * PURSUIT_ID_LEN), data, datalen);
    } else {
		return Py_BuildValue("(B,B,z#)",type, id_len, str_id, (id_len * PURSUIT_ID_LEN));
    }
    /*Add support for other types*/
}

static PyObject *baddernetlink_badderdisconnect(PyObject *self, PyObject *args, 
				 PyObject *keywds) {
		int sock_fd;
		int ret=0;
		static char *kwlist[] = {"sockfd",NULL};

    		if (!PyArg_ParseTupleAndKeywords(args, keywds, "I", kwlist,
				     &sock_fd)) { return NULL; }
		close(sock_fd);
		return Py_BuildValue("i", ret);
}

DL_EXPORT(void) initbaddernetlink(void) {
    PyObject *m;
    m = Py_InitModule("baddernetlink", baddernetlink_methods);
}

